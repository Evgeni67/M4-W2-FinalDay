import React from "react"

class GenericBody extends React.Component {
	render() {
		return(

			<div  className="cardsin pt-3 px-3 pb-0 ">
			Literally any content
		</div>

		) 
	}
}

export default GenericBody
